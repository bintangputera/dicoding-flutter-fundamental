const BASE_URL = "https://restaurant-api.dicoding.dev";
const IMAGE_URL = "https://restaurant-api.dicoding.dev/images/medium/";
